const fs = require("fs")
let handler = async (m, { conn, text }) => {
let putra = `
📚 _وَعَلَيْكُمْ السَّلاَمُ وَرَحْمَةُ اللهِ وَبَرَكَاتُهُ_\n_wa\'alaikumussalam wr.wb._`.trim()
let sound = fs.readFileSync('./media/salam.mp3')
await m.replyy(putra)
conn.sendMessage(m.chat, {
            audio: sound,
            fileName: 'mwahhh.mp3',
            mimetype: 'audio/mpeg',
            ptt: true
        }, {
            quoted: m
        })
}
handler.customPrefix = /^(assalam(ualaikum)?|(salamu'alaiku|(sa(lamu|m)liku|sala))m)$/i
handler.command = new RegExp
module.exports = handler