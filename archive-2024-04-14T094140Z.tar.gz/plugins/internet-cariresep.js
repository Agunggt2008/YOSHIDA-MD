const axios = require ('axios')
const fetch = require('node-fetch')
const cheerio = require('cheerio')

let handler = async (m, { conn, text, usedPrefix, command }) => {
  conn.resep = conn.resep ? conn.resep : {};
  if (!text) throw `Masukkan nama makanan nya\n*Contoh:* ${usedPrefix + command} nasi goreng`;
  let resep = await cariresep(text);
  let hasil = `*± C A R I R E S E P . C O M*\n 
*Creator:* ${resep.creator} 
*• Result search from:* ${text}
Type one of the numbers below to display food details\n*━━「 SESRCH RESULT 」━━*\n\n` + resep.data.map((item, index) => `*${index + 1}.* ${item.judul}`).join("\n");
  conn.reply(m.chat, hasil, m);

  conn.resep[m.chat] = resep
};

handler.before = async (m, { conn }) => {
  conn.resep = conn.resep ? conn.resep : {};
  if (m.isBaileys) return;
  if (!conn.resep[m.chat]) return;
  if (!m.text) return;
  if (isNaN(m.text) || m.text <= 0 || m.text > conn.resep[m.chat].data.length) return m.reply("🚫 Masukkan nomor bukan huruf");
  let { data, creator } = conn.resep[m.chat];
  let pilihan = data[m.text - 1].link;
  
    let url = await detailresep(pilihan);
    let hasil = `*± C A R I R E S E P . C O M*
*creator:* ${creator}
*Food name:* ${url.data.judul || "nothing"}
*Cooking time:* ${url.data.cooking_time || "nothing"}
*Difficulty level:* ${url.data.bahan || "nothing"}`;
    conn.sendFile(m.chat, url.data.thumb, null, hasil, m);
    delete conn.resep[m.chat];
};

handler.help = ["cariresep"].map(a => a + ' *Name food*');
handler.tags = ["internet"];
handler.command = ["cariresep","resep"];
handler.limit = 5;
module.exports = handler;

async function cariresep(query) {
    return new Promise(async (resolve, reject) => {
        axios.get('https://resepkoki.id/?s=' + query).then(({
                data
            }) => {
                const $ = cheerio.load(data)
                const link = [];
                const judul = [];
                const upload_date = [];
                const format = [];
                const thumb = [];
                $('body > div.all-wrapper.with-animations > div:nth-child(5) > div > div.archive-posts.masonry-grid-w.per-row-2 > div.masonry-grid > div > article > div > div.archive-item-media > a').each(function(a, b) {
                    link.push($(b).attr('href'))
                })
                $('body > div.all-wrapper.with-animations > div:nth-child(5) > div > div.archive-posts.masonry-grid-w.per-row-2 > div.masonry-grid > div > article > div > div.archive-item-content > header > h3 > a').each(function(c, d) {
                    let jud = $(d).text();
                    judul.push(jud)
                })
                for (let i = 0; i < link.length; i++) {
                    format.push({
                        judul: judul[i],
                        link: link[i]
                    })
                }
                const result = {
                    creator: 'Adi Selebew',
                    data: format.filter(v => v.link.startsWith('https://resepkoki.id/resep'))
                }
                resolve(result)
            })
            .catch(reject)
    })
}

async function detailresep(query) {
    return new Promise(async (resolve,
        reject) => {
        axios.get(query).then(({
                data
            }) => {
                const $ = cheerio.load(data)
                const abahan = [];
                const atakaran = [];
                const atahap = [];
                $('body > div.all-wrapper.with-animations > div.single-panel.os-container > div.single-panel-details > div > div.single-recipe-ingredients-nutritions > div > table > tbody > tr > td:nth-child(2) > span.ingredient-name').each(function(a, b) {
                    let bh = $(b).text();
                    abahan.push(bh)
                })
                $('body > div.all-wrapper.with-animations > div.single-panel.os-container > div.single-panel-details > div > div.single-recipe-ingredients-nutritions > div > table > tbody > tr > td:nth-child(2) > span.ingredient-amount').each(function(c, d) {
                    let uk = $(d).text();
                    atakaran.push(uk)
                })
                $('body > div.all-wrapper.with-animations > div.single-panel.os-container > div.single-panel-main > div.single-content > div.single-steps > table > tbody > tr > td.single-step-description > div > p').each(function(e, f) {
                    let th = $(f).text();
                    atahap.push(th)
                })
                const judul = $('body > div.all-wrapper.with-animations > div.single-panel.os-container > div.single-title.title-hide-in-desktop > h1').text();
                const waktu = $('body > div.all-wrapper.with-animations > div.single-panel.os-container > div.single-panel-main > div.single-meta > ul > li.single-meta-cooking-time > span').text();
                const hasil = $('body > div.all-wrapper.with-animations > div.single-panel.os-container > div.single-panel-main > div.single-meta > ul > li.single-meta-serves > span').text().split(': ')[1]
                const level = $('body > div.all-wrapper.with-animations > div.single-panel.os-container > div.single-panel-main > div.single-meta > ul > li.single-meta-difficulty > span').text().split(': ')[1]
                const thumb = $('body > div.all-wrapper.with-animations > div.single-panel.os-container > div.single-panel-details > div > div.single-main-media > img').attr('src')
                let tbahan = 'bahan\n'
                for (let i = 0; i < abahan.length; i++) {
                    tbahan += abahan[i] + ' ' + atakaran[i] + '\n'
                }
                let ttahap = 'tahap\n'
                for (let i = 0; i < atahap.length; i++) {
                    ttahap += atahap[i] + '\n\n'
                }
                const tahap = ttahap
                const bahan = tbahan
                const result = {
                    creator: 'Adi Selebew',
                    data: {
                        judul: judul,
                        waktu_masak: waktu,
                        hasil: hasil,
                        tingkat_kesulitan: level,
                        thumb: thumb,
                        bahan: bahan.split('bahan\n')[1],
                        langkah_langkah: tahap.split('tahap\n')[1]
                    }
                }
                resolve(result)
            })
            .catch(reject)
    })
}