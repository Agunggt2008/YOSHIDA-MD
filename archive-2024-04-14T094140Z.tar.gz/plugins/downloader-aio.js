const axios = require("axios")
let handler = async (m, { text, conn, usedPrefix, command }) => {
if (!text) return m.reply(Func.example(usedPrefix, command, 'Linknya'))
m.react("🕒") 

try {
let url = text
const { data } = await Func.fetchJson('https://allvideodownloader.cc/wp-json/aio-dl/video-data/', { url });

const yy = data;
const capt = `*Source:* ${yy.source}\n*Link:* ${yy.url}\n*Title:* ${yy.title}\n*Duration:* ${yy.duration}`
const masalahserius = yy.source
let videoUrl = data.medias.find(media => media.quality === 'hd').url

let q = await conn.sendFile(m.chat, yy.thumbnail, 'aio.png', capt, m);
conn.sendMessage(m.chat, { video: { url: videoUrl }, caption: null }, { quoted: q })

} catch {
try {
let url = text
const { data } = await Func.fetchJson('https://allvideodownloader.cc/wp-json/aio-dl/video-data/', { url });

const yy = data;
const capt = `*Source:* ${yy.source}\n*Link:* ${yy.url}\n*Title:* ${yy.title}\n*Duration:* ${yy.duration}`
let videoUrl = data.medias.find(media => media.quality === '720p').url

let q = await conn.sendFile(m.chat, yy.thumbnail, 'aio.png', capt, m);
conn.sendMessage(m.chat, { video: { url: videoUrl }, caption: null }, { quoted: q })

//await Func.delay(2000)
//await m.reply(Func.jsonFormat(body))

} catch (e) {
console.error(e)
throw e.toString()
}
}
}
handler.help = handler.command = ['aio']
handler.tags = ['downloader']
handler.limit = 1
module.exports = handler