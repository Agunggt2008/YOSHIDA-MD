let handler = async (m, { conn, text, usedPrefix, command }) => {
  if (!text) throw `*• Example:* ${usedPrefix + command} cat`
m.react('⏱️')
try {
let gpt = await (await fetch(`https://itzpire.site/ai/pixelart?prompt=${text}`)).json()
conn.sendFile(m.chat, gpt.result,null,"*[ PIXEL - ART ]* " + '\n*• Prompt:*' + text)
 } catch(e) {
 throw "`*Command Not Responded*`"
}
}
handler.help = ["pixel"]
handler.tags = ["ai"]
handler.command = ["pixel"]
module.exports = handler