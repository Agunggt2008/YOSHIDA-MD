const { sticker } = require('../lib/sticker2')

let handler = async (m, { conn }) => { 
let stiker = await sticker(null, global.API(`https://telegra.ph/file/634687ae82ba051fd5fcf.jpg`), global.packname, global.author)
    if (stiker) return await conn.sendFile(m.chat, stiker, 'sticker.webp', '', m)
}
handler.customPrefix = /^(@62882007855266|adi)$/i // ganti yang 628 dengan nomormu
handler.command = new RegExp

module.exports = handler