const fetch = require("node-fetch")
const fs = require('fs')
const { generateWAMessageFromContent } = require("@whiskeysockets/baileys")
let handler  = async (m, { conn }) => {

let totalf = '50'
let txt = `*乂  S O U R C E  -  C O D E  乂*\n\n`
txt += 'This code is not yet completely, and is not yet available for sale now!'
   await conn.relayMessage(m.chat,  {
    requestPaymentMessage: {
      currencyCodeIso4217: 'IDR',
      amount1000: 50000000,
      requestFrom: '0@s.whatsapp.net',
      noteMessage: {
      extendedTextMessage: {
      text: txt,
      contextInfo: {
      mentionedJid: [m.sender],
      externalAdReply: {
      showAdAttribution: true
      }}}}}}, {})
}
handler.tags = ["info"]
handler.help = ["script"]
handler.command = /^(script|sc|sourcecode)$/i;
module.exports = handler