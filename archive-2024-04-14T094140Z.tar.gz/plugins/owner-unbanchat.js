let handler = async (m) => {
global.db.data.chats[m.chat].isBanned = false
m.reply('Done Sayang!')
}
handler.help = ['unbanchat']
handler.tags = ['owner']
handler.command = /^(unbanchat|unmute)$/i
handler.owner = true

module.exports = handler