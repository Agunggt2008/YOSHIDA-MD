const fetch = require('node-fetch');

let handler = async (m, { conn, text }) => {
    if (!text) {
        console.log('judul tidak ditemukan.');
        throw m.reply(`*MASUKAN JUDUL*\n\nCONTOH . spotify dj aku yang terluka`) 
    }
  m.react('🎶') 
    const query = encodeURIComponent(text);
    let res = `https://guruapi.tech/api/spotifydl?url=${query}`
await conn.sendMessage(m.chat, {
                audio: {
                    url: res
                },
                mimetype: 'audio/mpeg',
                contextInfo: {
                    externalAdReply: {
                        title: "S P O T I F Y - S O N G",
                        body: "",
                        thumbnailUrl: "https://telegra.ph/file/d80d58ffa60a7570d3396.jpg",
                        sourceUrl: "https://open.spotify.com",
                        mediaType: 1,
                        showAdAttribution: true,
                        renderLargerThumbnail: true
                    }
                }
            }, {
                quoted: m
            });
}
handler.help = ['spotify'];
handler.tags = ['downloader'];
handler.command = /^(spotify|spt|sptsong|spotifysong)$/i;

module.exports = handler;