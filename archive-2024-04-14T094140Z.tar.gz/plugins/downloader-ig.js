const fetch = require('node-fetch')
let handler = async (m, {
	usedPrefix,
	command,
	args
}) => {
	if (!args[0]) return m.reply(Func.example(usedPrefix, command, 'https://www.instagram.com/p/CvhKFLaLWXJ/?utm_source=ig_web_copy_link&igshid=MzRlODBiNWFlZA=='))
	if (!args[0].match(/(https:\/\/www.instagram.com)/gi)) return m.reply(status.invalid)
	let old = new Date()
	m.react('⏱️')
	try {
  const igdl = await (await fetch('https://skizo.tech/api/ig', {
  method: 'POST',
  body: JSON.stringify({
    url: args[0]
  }),
  headers: {
    'Content-Type': 'application/json',
    'Authorization': XznKey
  }
})).json();
//return igdl
for (let i of igdl) {
conn.sendFile(m.chat, i.url, '', '', m);
}
} catch (e) {
console.log(e)
return m.replyy(eror)
	}
}
handler.help = ['instagram']
handler.tags = ['downloader']
handler.command = ['ig', 'instagram']
handler.limit = 5
module.exports = handler