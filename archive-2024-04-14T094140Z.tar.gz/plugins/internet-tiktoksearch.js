const axios = require ('axios')
const fetch = require('node-fetch')
const cheerio = require('cheerio')

let handler = async (m, { conn, text, usedPrefix, command }) => {
  try {
    conn.ttsearch = conn.ttsearch ? conn.ttsearch : {};
    if (!text) {
      return  conn.reply(m.chat, `*Example:* ${usedPrefix + command} Jedag Jedug Epep`, m);
    }
    
    m.react('🔎');
    let res = await ttSearch(text);    
    let hasil = res.videos.map((v, index) => `*${index + 1}.* *Title:* ${v.title}\n*Region:* ${v.region}`).join("\n\n");
    let url = 'https://tikwm.com' + res.videos[0].cover;  
    let { key } = await conn.sendMessage(m.chat,{image: {url: url},caption: hasil},{quoted: m});
    await conn.reply(m.chat,`Pilih Angka Urutan *1 - ${res.videos.length}* sesuai pesan di atas`, null)
    conn.ttsearch[m.sender] = res;
  } catch (error) {
    console.log(error);
   conn.reply(m.chat, 'An error occurred while executing the command', m);
  }
};

handler.before = async (m, { conn }) => {
  try {
    conn.ttsearch = conn.ttsearch ? conn.ttsearch : {};
    if (m.isBaileys) return;
    if (!m.text) return;
    if (!conn.ttsearch[m.sender]) return;
    if (isNaN(m.text) || m.text <= 0 || m.text > conn.ttsearch[m.sender].videos.length) return

    let { videos } = conn.ttsearch[m.sender];
    let pilihan = videos[m.text - 1].play;  
    let Video = 'https://tikwm.com' + pilihan;  
    m.react('⏱️');
    await conn.sendFile(m.chat, Video, null, videos[m.text - 1].title, m);
    delete conn.ttsearch[m.sender];
  } catch (error) {
    console.log(error);
    conn.reply(m.chat, 'An error occurred while executing the command', m);
  }
};

handler.help = ['tiktoksearch'].map(a => a + ' *[search videos from tiktok]*');
handler.tags = ['internet', 'downloader'];
handler.command = ['tiktoks', 'tiktoksearch', 'ttsearch']
handler.premium = true;
module.exports = handler;

async function ttSearch(query) {
		return new Promise(async (resolve, reject) => {
			axios("https://tikwm.com/api/feed/search", {
				headers: {
					"content-type": "application/x-www-form-urlencoded; charset=UTF-8",
					cookie: "current_language=en",
					"User-Agent":
						"Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Mobile Safari/537.36",
				},
				data: {
					keywords: query,
					count: 12,
					cursor: 0,
					web: 1,
					hd: 1,
				},
				method: "POST",
			}).then((res) => {
				resolve(res.data.data);
			});
		});
	}