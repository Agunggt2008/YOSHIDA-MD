const fetch = require('node-fetch')
const { fetchJson } = require('../lib/myfunc')
let handler = async (m, { conn, text }) => {
try {
let meme = await fetchJson(`https://skizo.tech/api/randommeme?apikey=${global.XznKey}`)
const hasil = meme.media
const capt = meme.caption
await conn.sendFile(m.chat, hasil, null, `${capt}`, m)
} catch (e) {
throw `Meme Gak Ketemu Min:v`
 }
}
handler.command = /^(meme)$/i
handler.tags = ['fun']
handler.help = ['meme']
handler.limit = true
module.exports = handler
