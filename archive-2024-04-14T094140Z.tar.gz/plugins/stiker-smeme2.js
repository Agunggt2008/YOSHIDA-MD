const uploadFile = require('../lib/uploadFile.js')
const uploadImage = require('../lib/uploadImage.js')
const {
    webp2png
} = require('../lib/webp2mp4.js')
const {
    Sticker,
    StickerTypes
} = require('wa-sticker-formatter')
const {
    sticker
} = require('../lib/sticker.js')

let handler = async (m, {
    conn,
    args,
    text,
    usedPrefix,
    command
}) => {
    var out
    let who = m.mentionedJid && m.mentionedJid[0] ? m.mentionedJid[0] : m.fromMe ? conn.user.jid : m.sender
    let name = m.name
    let [atas, bawah] = text.split(/[^\w\s]/g)

    let q = m.quoted ? m.quoted : m
    let mime = (q.msg || q).mimetype || q.mediaType || ''
    if (/video/g.test(mime)) {
        if ((q.msg || q).seconds > 11) return m.reply('Maksimal 10 detik!')
    }
    if (!/webp|image|video|gif|viewOnce/g.test(mime)) return m.reply(`Reply Media dengan perintah\n\n${usedPrefix + command} <${atas ? atas : 'teks atas'}>|<${bawah ? bawah : 'teks bawah'}>`)
    let img = await q.download?.()
    let meme = "https://api.memegen.link/images/custom/" + encodeURIComponent(atas ? atas : '_') + "/" + encodeURIComponent(bawah ? bawah : '_') + ".png?background="

    if (/webp/g.test(mime)) {
        out = await createSticker(meme + await webp2png(img), false, packname, name, 60)
    } else if (/image/g.test(mime)) {
        out = await createSticker(meme + await uploadImage(img), false, packname, name, 60)
    } else if (/video/g.test(mime)) {
        out = await sticker(meme + await uploadFile(img), false, packname, name)
    } else if (/gif/g.test(mime)) {
        out = await createSticker(meme + await uploadFile(img), false, packname, name, 60)
    } else if (/viewOnce/g.test(mime)) {
        out = await createSticker(meme + await uploadFile(img), false, packname, name, 60)
    }
    if (out) {
        conn.sendFile(m.chat, out, 'memek', '', m)
    } else {
        throw eror
    }

}
handler.help = ['smeme2']
handler.tags = ['sticker']
handler.command = ['smeme2','sm2']

module.exports = handler

const isUrl = (text) => {
    return text.match(new RegExp(/https?:\/\/(www\.)?[-a-zA-Z0-9@:%._+~#=]{1,256}\.[a-zA-Z0-9()]{1,6}\b([-a-zA-Z0-9()@:%_+.~#?&/=]*)(jpe?g|gif|png)/, 'gi'))
}

async function createSticker(img, url, packName, authorName, quality) {
    let stickerMetadata = {
        type: StickerTypes.FULL,
        pack: packName,
        author: authorName,
        quality
    }
    return (new Sticker(img ? img : url, stickerMetadata)).toBuffer()
}

async function createStickerV(img, url, packName, authorName, quality) {
    let stickerMetadata = {
        type: StickerTypes.CROPPED,
        pack: packName,
        author: authorName,
        quality
    }
    return (new Sticker(img ? img : url, stickerMetadata)).toBuffer()
}