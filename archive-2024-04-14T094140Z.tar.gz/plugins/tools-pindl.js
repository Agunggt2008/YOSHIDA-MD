let handler = async (m, { conn, args, usedPrefix, command, text }) => {
if (!text) return m.reply(Func.example(usedPrefix, command, 'https://pin.it/2sofHzZ'))
m.react("🕒");

const api = await fetch(`https://aemt.me/download/pindl?url=${args[0]}`);
const res = await api.json();
let { media_type, image, title } = res.result.data;
if (media_type === 'video/mp4') {
await conn.sendMessage(m.chat, {video: { url: image }, caption: `*乂 Downloader Pinterest*\n\n∘ *Title :* ${title}\n∘ *Mediatype :* ${media_type}\n∘ *Source Url :* ${image}`},{quoted:m});
} else {
conn.sendFile(m.chat, image, 'pindl.png', `*乂 Downloader Pinterest*\n\n∘ *Title :* ${title}\n∘ *Mediatype :* ${media_type}\n∘ *Source Url :* ${image}`, m);
}
}
handler.help = ['pindl'];
handler.tags = ['downloader'];
handler.command = /^(pindl)$/i;
handler.limit = true;

module.exports = handler