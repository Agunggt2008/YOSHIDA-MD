/** enter owner number */
global.owner = ['62882007855266']
 /** global link */
global.gcl = 'https://chat.whatsapp.com/HnoKcpzYsKE5y0thEM060h',
global.saluran = 'https://whatsapp.com/channel/0029VaBB5zLF1YlNMoA6YD0b',
global.sig = 'https://instagram.com/adisptr05_',
global.fb = 'https://www.facebook.com/profile.php?id=100047728149367&mibextid=JRoKGi',
global.sfb = global.fb
 /** global Nomor */
global.nomorbot = '6282375933838', //Nomor Bot
global.modz = '62882007855266',
global.nomorown = '62882007855266' 
 //====Global Apikey
global.maxwarn = '3',
global.lann = 'LbVqmmtg',
global.rose = 'yayaya',
global.btc = 'jfCgnAHY',
global.BotKey = 'junaa',
global.lolkey = 'GataDios',
global.XznKey = 'yoshidaxyz',
global.openaikey = "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"
/** Apikey https://api.alyachan.pro/pricing */
global.APIs = {
alya: 'https://api.alyachan.pro',
 lol: 'https://api.lolhuman.xyz',
lann: 'https://api.betabotz.eu.org'
}
global.APIKeys = {
  'https://api.alyachan.pro': 'Yoshx200',
    'https://api.lolhuman.xyz': 'GataDios',
    'https://api.betabotz.eu.org': 'beta-mylifebot14'
}

/** option setting */
global.set = {
  wm : `Yoshida Wabot V${require('./package.json').version}`,
  footer: 'ᴘᴏᴡᴇʀᴇᴅ ʙʏ ʏᴏsʜɪᴅᴀ',
  tanda: '© ᴍᴜʟᴛɪᴘᴜʀᴘᴏsᴇ-ᴡᴀʙᴏᴛ ᴍᴀᴅᴇ ʙʏ ᴀᴅɪxsɴᴢᴢ',
  packname: 'Yoshida',
  author: '@Adi.Dev'
}
/** wm dan sebagainya*/
global.nomorbot = '6282375933838',
global.nomorown = '62882007855266',
global.eror = 'Terjadi Kesalahan',
global.wait = 'In Progress...',
global.wm = '© YOSHIDA - TECH',
global.namebot = 'ʏᴏsʜɪᴅᴀ-ᴍᴅ',
global.nameown = '@ʙᴀɴɢ_ᴀᴅɪ',
global.packname = 'Yoshida',
global.author = 'Yoshx-Team'
/** Global Payment*/
global.povo = '085267445570', // Nomor Rek Ovo
global.pdana = '0882007855266',
global.gopay = '085267445570',
global.psaweria = 'https://saweria.co/Adisptro'
/** enter your bot number to login using the code */
global.pairingNumber = '6282375933838'
/** enter your replit link, so it's active 24/7 */
global.replit_url = ''

/** other */
global.multiplier = 1000 // The bigger it gets the harder it is to level up
global.max_upload = 70 // Maximum limit to send files
global.intervalmsg = 1800 // To avoid spam on first login
global.ram_usage = 2100000000 // Maximum 2GB ram, do the math yourself

/** function and scraper to make it more practical */
global.Func = new (require('./lib/functions'))
global.scrap = new (require('./lib/scrape'))

/** status message */
global.status = {
  wait: 'Processing. . .',
  invalid: 'Url invalid!',
  wrong: 'Format salah!',
  error: 'Lagi eror cuyy🙏',
  premium: 'Fitur khusus anggota premium.',
  admin: 'Fitur khusus admin.',
  botAdmin: 'Bot harus menjadi admin untuk menggunakan fitur ini.',
  owner: 'Fitur khusus owner.',
  mod: 'Fitur khusus moderator.',
  group: 'Fitur khusus digunakan didalam grup.',
  private: 'Fitur khusus private chat.',
  register: 'Mohon daftar terlebih dahulu untuk menggunakan fitur ini.',
  game: 'Fitur game belum di aktifkan.',
  rpg: 'Fitur RPG belum di aktifkan saat ini.',
  restrict: 'Udah off cuyy'
}
global.flaaa = [

'https://www6.flamingtext.com/net-fu/proxy_form.cgi?&imageoutput=true&script=sketch-name&doScale=true&scaleWidth=800&scaleHeight=500&fontsize=100&fillTextType=1&fillTextPattern=Warning!&text=', 

'https://flamingtext.com/net-fu/proxy_form.cgi?&imageoutput=true&script=water-logo&script=water-logo&fontsize=90&doScale=true&scaleWidth=800&scaleHeight=500&fontsize=100&fillTextColor=%23000&shadowGlowColor=%23000&backgroundColor=%23000&text=',

'https://flamingtext.com/net-fu/proxy_form.cgi?&imageoutput=true&script=crafts-logo&fontsize=90&doScale=true&scaleWidth=800&scaleHeight=500&text=',

'https://flamingtext.com/net-fu/proxy_form.cgi?&imageoutput=true&script=amped-logo&doScale=true&scaleWidth=800&scaleHeight=500&text=',

'https://www6.flamingtext.com/net-fu/proxy_form.cgi?&imageoutput=true&script=sketch-name&doScale=true&scaleWidth=800&scaleHeight=500&fontsize=100&fillTextType=1&fillTextPattern=Warning!&text=',

'https://www6.flamingtext.com/net-fu/proxy_form.cgi?&imageoutput=true&script=sketch-name&doScale=true&scaleWidth=800&scaleHeight=500&fontsize=100&fillTextType=1&fillTextPattern=Warning!&fillColor1Color=%23f2aa4c&fillColor2Color=%23f2aa4c&fillColor3Color=%23f2aa4c&fillColor4Color=%23f2aa4c&fillColor5Color=%23f2aa4c&fillColor6Color=%23f2aa4c&fillColor7Color=%23f2aa4c&fillColor8Color=%23f2aa4c&fillColor9Color=%23f2aa4c&fillColor10Color=%23f2aa4c&fillOutlineColor=%23f2aa4c&fillOutline2Color=%23f2aa4c&backgroundColor=%23101820&text='] 

//Ewe 
/** rpg emoticon */
global.rpg = {
  emoticon(string) {
    string = string.toLowerCase()
    let emot = {
      exp: '✉️',
      money: '💵',
      potion: '🥤',
      diamond: '💎',
      common: '📦',
      uncommon: '🎁',
      mythic: '🗳️',
      legendary: '🗃️',
      pet: '🎁',
      trash: '🗑',
      armor: '🥼',
      sword: '⚔️',
      wood: '🪵',
      rock: '🪨',
      string: '🕸️',
      horse: '🐎',
      cat: '🐈',
      dog: '🐕',
      fox: '🦊',
      petFood: '🍖',
      iron: '⛓️',
      gold: '👑',
      emerald: '💚',
    }
    let results = Object.keys(emot).map((v) => [v, new RegExp(v, 'gi')]).filter((v) => v[1].test(string))
    if (!results.length) return ''
    else return emot[results[0][0]]
  },
}

/** reload file */
const fs = require('fs')
const chalk = require('chalk')
let file = require.resolve(__filename)
fs.watchFile(file, () => {
  fs.unwatchFile(file)
  console.log(chalk.redBright("Update 'config.js'"))
  delete require.cache[file]
  require(file)
})