const uploadImage = require("../lib/uploadImage");
const axios = require("axios");

let handler = async (m, { conn, text }) => {
    if (!text) return m.reply('Ndi text e')
    let q = m.quoted ? m.quoted : m;
    if (!/image/gi.test(q.mtype)) return m.reply("Mohon tag gambar cuk");
    let uploaded = await uploadImage(await q.download());
    let url = `https://api.onesytex.my.id/api/gemini-vision?text=${text}&url=${uploaded}`;
    const { data: gemini } = await axios.get(url);
    m.reply(gemini.result.data);
}

handler.command = /^geminipro$/i;
handler.help = ['geminipro'];
handler.tags = ['ai'];

module.exports = handler;