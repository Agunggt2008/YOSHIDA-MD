let handler = async (m, { conn, text, usedPrefix, command }) => {
let teks = `
︵‿︵‿︵ *SEWA BOT* ︵‿︵‿︵
❏──「 *Sewa Bot* 」
│ • *1 Minggu:* Rp.5.000
│ • *1 Bulan:* Rp.10.000
│ • *Permanen:* Rp.20.000
❏──────────────๑
❏──「 *Premium* 」
│ • *1 Minggu:* Rp.5.000
│ • *2 Minggu:* Rp.10.000
│ • *1 Bulan:* Rp.15.000
│ • *Permanen:* Rp.20.000
❏──────────────๑
❏──「 *Pembayaran* 」
│ • *Ovo:* [${global.povo}]
│ • *Dana:* [${global.pdana}]
│ • *Qris:* Hub owner
❏──────────────๑
│ 📌 Hubungi Owner!!!
❏──────────────๑

*ʙᴀᴄᴋ ᴛᴏ ᴀʟʟ ᴍᴇɴᴜ*: .menu
*ᴘɪɴɢ*: .ping
*ᴄʀᴇᴀᴛᴏʀ*: .owner
︵‿︵‿︵‿︵︵‿︵‿︵‿
Created by ${global.wm}
`

    await conn.relayMessage(m.chat,  {
    requestPaymentMessage: {
      currencyCodeIso4217: 'IDR',
      amount1000: 20000000,
      requestFrom: m.sender,
      noteMessage: {
      extendedTextMessage: {
      text: teks,
      contextInfo: {
      externalAdReply: {
      showAdAttribution: true
      }}}}}}, {})
}

handler.help = ['sewa', 'premium']
handler.tags = ['info']
handler.command = /^(sewa(bot)?|premium)$/i

module.exports = handler
