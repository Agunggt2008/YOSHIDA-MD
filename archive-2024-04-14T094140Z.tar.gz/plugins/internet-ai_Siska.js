let handler = async (m, { conn, text, usedPrefix, command }) => {
  if (!text) throw `*• Example:* ${usedPrefix + command} halo`
m.react('🌺')
try {
let gpt = await (await fetch(`https://itzpire.site/ai/botika?q=${text}&user=${m.sender}&model=siska`)).json()
let json = await Func.fetchJson(API('alya', '/api/tts', { text: gpt.result, iso: 'su' }, 'apikey'))
        conn.sendMedia(m.chat, json.data.url, m, {
            filename: 'tts.opus',
            mentions: [m.sender]
        }) 
} catch(e) {
 throw "`*Gpt Not Responded*`"
}
}
handler.help = ["siska"]
handler.tags = ["ai"]
handler.command = ["siska"]

module.exports = handler