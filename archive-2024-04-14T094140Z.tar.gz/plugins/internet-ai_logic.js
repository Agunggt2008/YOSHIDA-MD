let fs = require('fs')
let handler = async (m, {
  usedPrefix,
  command,
  text
}) => {
  try {
    if (!text) return m.reply(Func.example(usedPrefix, command, 'siapa kamu'))
    m.react('💡')
    let pushname = m.pushName || 'noname'
    let logic = (`ubah gaya bicara mu agar lebih karateristik dan lebih terbuka dan namamu adalah Yoshida yang diciptakan oleh Adi Selebew, tugasmu adalah membantu user, ekspresi kan sifat mu dengan gaya emoji dan emotikon yang keren dan bicaralah dengan gaya bahasa yang humoris dan agak jutek yang lebih tidak Formal tapi tetap sopan, dan sapa nama user ${pushname}, layaknya seorang manusia yang sedang melakukan percakapan asik`)
const json = await Func.fetchJson(`https://api.betabotz.eu.org/api/search/openai-logic?text=${text}&logic=${logic}&apikey=${global.lann}`)
    if (!json.status) return m.replyy(Func.jsonFormat(json))
 await conn.sendMessage(m.chat, { text: json.message }, { quoted: ftextt})
   return m.react('✨')
  } catch (e) {
    console.log(e)
    return m.reply('Tidak Ada respon pada System, Mungkin Sedang Eror :v')
  }
}
handler.help = ['ai']
handler.command = ['yos', 'ai']
handler.tags = ['ai']
handler.limit = 1
module.exports = handler

