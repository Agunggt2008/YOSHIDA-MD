let handler = async (m, { conn, text, usedPrefix, command }) => {
if (!text) throw `*• Example:* ${usedPrefix + command} halo`
m.react('🌸')
try {
let model
let gpt = await (await fetch(`https://itzpire.site/ai/botika?q=${text}&user=${m.name}&model=alicia`)).json()
m.replyy(gpt.result)
} catch(e) {
 throw "`*Command Not Responded*`"
}
}
handler.help = ["ai-alicia"]
handler.tags = ["ai"]
handler.command = ["ai-alicia", "alicia"]
module.exports = handler