// Made By Adixshnzz 
let handler = async (m, { conn, text, usedPrefix, command }) => {
  if (!text) throw "*• Example:* " + usedPrefix + command + " halo";
  m.react('🌐');
  let a = await Func.fetchJson(
    "https://itzpire.site/ai/you?q=" +
      text,
  );
await conn.sendMessage(m.chat, {
text: a.result.message,
contextInfo: {
externalAdReply: { 
title: 'Y O U - A I',
body: '',
thumbnailUrl: "https://telegra.ph/file/dbbbeb5c4076d537d68b7.jpg",
sourceUrl: 'https://www.you.ai',
mediaType: 1,
renderLargerThumbnail: true
}}}, { quoted: ftextt});
};

handler.help = ["youai"]
handler.command = ["aiy", "aiyou", "youai"];
module.exports = handler;