let handler = async(m, {
  usedPrefix,
  command,
  text
}) => {
  try {
    if (!text) return m.reply(Func.example(usedPrefix, command, 'Yoshida Bot'))
    m.react('✍️')
    await conn.sendMessage(m.chat, {image:{url:`https:\/\/api.zeeoneofc.my.id/api/canvas/${command}?text=${text}&apikey=${global.BotKey}`}, caption: "Nih kak"}, {quoted: m}).catch(async _ => await m.reply("apikey sedang eror"))
  } catch (e) {
    console.log(e)
    return m.reply('Terjadi Kesalahan..')
  }
}
handler.help = ['foliokanan']
handler.tags = ['tools']
handler.command = ['foliokanan']
handler.limit = 1
module.exports = handler