
let handler = m => m

let linkRegex = /chat.whatsapp.com\/([0-9A-Za-z]{20,24})/i
handler.before = async function (m, { user, isBotAdmin, isAdmin }) {
  if ((m.isBaileys && m.fromMe) || m.fromMe || !m.isGroup) return true
  let chat = global.db.data.chats[m.chat]
  let isGroupLink = linkRegex.exec(m.text)

 if (chat.antilink && isGroupLink) {
await this.reply(
            m.chat,
            'Antilink Detected 🚫',
            m, {
                contextInfo: {
                    mentionedJid: m.messageStubParameters[0] !== undefined ? [m.sender, m.messageStubParameters[0]] : [m.sender],
                    externalAdReply: {
                        title: 'A N T I L I N K',
                        thumbnail: await (await this.getFile("https://telegra.ph/file/ed5cdf4080368e82171b1.png")).data
                    },
                },
            }
        )
    if (isAdmin) return m.replyy('*Is Admin:* Maaf Kamu Admin')
    let linkGC = ('https://chat.whatsapp.com/' + await conn.groupInviteCode(m.chat))
    let isLinkconnGc = new RegExp(linkGC, 'i')
    let isgclink = isLinkconnGc.test(m.text)
    await conn.sendMessage(m.chat, { delete: m.key })
    await this.sendMessage(m.chat, { delete: { remoteJid: m.chat, fromMe: false, id: m.key.id, participant: m.key.participant }});
  }
  return true
}

module.exports = handler