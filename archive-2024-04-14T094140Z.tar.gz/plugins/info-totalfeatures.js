let Baileys = require("@whiskeysockets/baileys")
let handler = async (m, {
  conn,
  args,
  command
}) => {
  let totalf = Object.values(global.plugins).filter((v) => v.help && v.tags).length
  let pitur = `» *Jumlah Total Fitur Saat Ini :* _${totalf} 🚀_`
conn.reply(m.chat, pitur, fload)
}
handler.help = ['totalfeatures']
handler.tags = ['info']
handler.command = /^(total(fitur|feature)?)$/i
module.exports = handler
