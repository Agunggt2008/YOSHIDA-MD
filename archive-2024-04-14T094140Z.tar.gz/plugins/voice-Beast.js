const fetch = require('node-fetch')
let handler = async (m, {
    args,
    usedPrefix,
    text,
    command
}) => {
    if (!text) throw `Masukan text nya!\n\nExample: ${usedPrefix + command} Hello Sir`
    try {
        let audio = await (await fetch(`https://itzpire.site/tools/tts-beast?text=${text}`)).json()
        await conn.sendFile(m.chat, audio.result, '', '', m, null, {
     ptt: true,
     waveform: [100, 0, 100, 0, 100, 0, 100],
     contextInfo: {
         externalAdReply: { 
    showAdAttribution: true,
    mediaUrl: global.fb,
    mediaType: 2, 
    description: '',
    title: 'M R - B E A S T',
    body: '',
    thumbnail: await (await fetch(`https://telegra.ph/file/cdb32631714d2568270d6.jpg`)).buffer(),
    sourceUrl: ''
 	  }
     }
    })
    } catch (e) {
        m.reply('Error!')
    }
}

handler.help = ['mr-beast']
handler.tags = ['voice']
handler.command = ['mr-beast', 'beast']
handler.limit = true
module.exports = handler 