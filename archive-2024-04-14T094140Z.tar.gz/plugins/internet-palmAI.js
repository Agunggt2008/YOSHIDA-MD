let handler = async (m, { conn, text, usedPrefix, command }) => {
  if (!text) throw `*• Example:* ${usedPrefix + command} halo`
m.react('🌴')
try {
let palm = await (await fetch(`https://itzpire.site/ai/palm-ai?q=${text}`)).json()
await conn.sendMessage(m.chat, {
text: palm.result,
contextInfo: {
externalAdReply: { 
title: 'P A L M 2',
body: '',
thumbnailUrl: "https://telegra.ph/file/bbc25d2187bcb706ef2c2.jpg",
sourceUrl: 'https://ai.google/palm2',
mediaType: 1,
renderLargerThumbnail: true
}}}, { quoted: ftextt})
 } catch(e) {
 throw "`Server Not Responded`"
}
}
handler.help = ["palm-ai"]
handler.tags = ["ai"]
handler.command = ["palm-ai", "palm"]
module.exports = handler