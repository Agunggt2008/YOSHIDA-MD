const { downloadContentFromMessage } = require('@whiskeysockets/baileys')

let handler = async (m, { conn, isOwner }) => {
  if (!m.quoted) throw 'Mana gambarnya 😠'
  if (m.quoted.mtype !== 'viewOnceMessageV2') throw 'Gk ada tuh'
  if (!isOwner) return m.reply('Malas menanggapi 🧢')
  let msg = m.quoted.message
  let type = Object.keys(msg)[0]
  let media = await downloadContentFromMessage(msg[type], type == 'imageMessage' ? 'image' : 'video')
  let buffer = Buffer.from([])
  for await (const chunk of media) {
    buffer = Buffer.concat([buffer, chunk])
  }
  if (/video/.test(type)) {
    return conn.sendFile(m.chat, buffer, 'media.mp4', msg[type].caption || '', m)
  } else if (/image/.test(type)) {
    return conn.sendFile(m.chat, buffer, 'media.jpg', msg[type].caption || '', m)
  }
}

handler.customPrefix = /^(apatuh|liat)$/i
handler.command = new RegExp

module.exports = handler