let Baileys = require("@whiskeysockets/baileys")
const os = require('os')
let handler = async (m, {
  conn
}) => {
  try {
    const json = await Func.fetchJson('http://ip-api.com/json')
    delete json.status
    let caption = `乂  *S E R V E R*\n\n`
    caption += `┌  ◦  OS : ${os.type()} (${os.arch()} / ${os.release()})\n`
    caption += `│  ◦  Ram : ${Func.formatSize(process.memoryUsage().rss)} / ${Func.formatSize(os.totalmem())}\n`
    for (let key in json) caption += `│  ◦  ${Func.ucword(key)} : ${json[key]}\n`
    caption += `│  ◦  Uptime : ${Func.toTime(os.uptime * 1000)}\n`
    caption += `└  ◦  Processor : ${os.cpus()[0].model}\n\n`
    const msg = Baileys.generateWAMessageFromContent(
			m.chat,
			{
				interactiveMessage: {
					body: {
						text: caption
					},
					footer: {
						text: global.set.tanda
					},
					header: {
						title: '',
						hasMediaAttachment: false,
						// ...image.message,
					},
					nativeFlowMessage: {
						buttons: [ {text: ""} ]
					}
				}, 
			},
			{
				quoted: ftextt
			}
		);
  await conn.relayMessage(m.chat, msg.message, m)
  } catch(e) {
    return m.reply(String(e))
  }
}
handler.help = ['server']
handler.tags = ['info']
handler.command = /^(server)$/i
module.exports = handler