const { createHash } = require('crypto')
let handler = async (m, { text, usedPrefix }) => {
let user = global.db.data.users[m.sender]
if(user.registered !== false) throw 'Kamu Sudah mendaftar!!\nIngin daftar ulang? ketik unreg'
    user.registered = true
    let sn = createHash('md5').update(m.sender).digest('hex')
    let p = `*Selamat Kamu sudah Mendaftar ✅*\n•Ketik Menu Untuk Melanjutkan\n\n•Sn Kamu: *${sn}*`
    const arr = [
        { text: `*[ D ]*\n\n${p}`, timeout: 100 },
        { text:  `*[ D A ]*\n\n${p}`, timeout: 100 },
        { text:  `*[ D A F ]*\n\n${p}`, timeout: 100 },
        { text:  `*[ D A F T ]*\n\n${p}`, timeout: 100 },
        { text:  `*[ D A F T A ]*\n\n${p}`, timeout: 100 },
        { text:  `*[ D A F T A R ]*\n\n${p}`, timeout: 100 },
        { text:  `*[ S ]*\n\n${p}`, timeout: 100 },
        { text:  `*[ S U ]*\n\n${p}`, timeout: 100 },
        { text:  `*[ S U K ]*\n\n${p}`, timeout: 100 },
        { text:  `*[ S U K S ]*\n\n${p}`, timeout: 100 },
        { text:  `*[ S U K S E ]*\n\n${p}`, timeout: 100 },
        { text:  `*[ S U K S E S ]*\n\n${p}`, timeout: 100 },
    ];

    const lll = await conn.sendMessage(m.chat, { text: 'S E D A N G D A F T A R O T O M A T I S ....' }, { quoted: m });

    for (let i = 0; i < arr.length; i++) {
        await new Promise(resolve => setTimeout(resolve, arr[i].timeout));
        await conn.relayMessage(m.chat, {
            protocolMessage: {
                key: lll.key,
                type: 14,
                editedMessage: {
                    conversation: arr[i].text
                }
            }
        }, {});
    }
}

handler.help = ['verify']
handler.tags = ['xp']
handler.command = /^(verify)$/i

module.exports = handler