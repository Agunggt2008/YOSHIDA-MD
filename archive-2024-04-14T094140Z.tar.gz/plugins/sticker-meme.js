const uploadImage = require('../lib/uploadFile')
let handler = async (m, { 
  conn,
  text,
  usedPrefix,
  command
}) => {
    let q = m.quoted ? m.quoted : m
    let mime = (q.msg || q).mimetype || ''
    if (!mime) throw `balas gambar dengan perintah\n\n${usedPrefix + command} teks atas | teks bawah`
    if (!/image\/(jpe?g|png)/.test(mime)) throw `_*Mime ${mime} tidak didukung!*_`
    atas = text.split('|')[0] ? text.split('|')[0] : '-'
    bawah = text.split('|')[1] ? text.split('|')[1] : '-'
    let img = await q.download()
    let url = await uploadImage(img)
    let meme = `https://api.memegen.link/images/custom/${encodeURIComponent(atas)}/${encodeURIComponent(bawah)}.png?background=${url}`
    conn.sendSticker(m.chat, meme, m, {
      packname: global.set.packname,
      author: global.set.author
    })
}
handler.help = ['smeme']
handler.tags = ['sticker']
handler.command = ['smeme', 'stickermeme', 'stikermeme']

handler.limit = 1

module.exports = handler