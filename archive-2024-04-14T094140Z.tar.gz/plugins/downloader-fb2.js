const fetch = require("node-fetch")

let handler = async (m, { conn, text, usedPrefix, command }) => {
   if (!text) throw `*• Example:* ${usedPrefix + command} *[Facebook url]*`
m.react('⚡')
  try {
let fb = await(await fetch('https://skizo.tech/api/fb', {
  method: 'POST',
  body: JSON.stringify({
    url: text,
  }),
  headers: {
    'Content-Type': 'application/json',
    Authorization: "yoshidaxyz"
  }
})).json();
    conn.sendMessage(m.chat,{ video: {
          url: fb[0].url
}, caption: "F A C E B O O K  D O W N" }, { quoted: m })
 } catch(e) {
 throw "`Terjadi Kesalahan..`"
 }
}
handler.help = ["facebook2"].map(a => a + " *url*")
handler.tags = ["downloader"]
handler.command = ["fb2","facebook2","fbdl2"]
module.exports = handler