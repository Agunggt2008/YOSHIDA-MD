let handler = async (m, { text }) => {
let pushname = m.pushName || `${senderNumber}`
let Baileys = require("@whiskeysockets/baileys")
  let user = global.db.data.users[m.sender]
  user.afk = + new Date
  user.afkReason = text
  let suwun = `@${m.sender.split('@')[0]}`
  let lungo = `» ${suwun} *Is Now AFK*\n» ${text ? '*Alasan* : ' + text : '_*Tanpa alasan*_'}`
  conn.reply(m.chat, lungo, fkontak)
}
handler.help = handler.command = ['afk']
handler.tags = ['group']
module.exports = handler