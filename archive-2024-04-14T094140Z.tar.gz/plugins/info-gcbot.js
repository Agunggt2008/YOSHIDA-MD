let handler = async (m, {conn}) => {
conn.reply(m.chat, gcl, m)
}
handler.help = ['gcbot']
handler.tags = ['info']
handler.command = /^(groupbot|gcbot)$/i

module.exports = handler