const fetch = require('node-fetch')
let handler = async (m, {
  conn,
  usedPrefix,
  command,
  text
}) => {
try {
m.react('🔥')
let baka = await fetch(`https://api.zeeoneofc.my.id/api/nsfw/${command}?apikey=junaa`)
await conn.sendMessage(m.chat, {image: baka, caption: `Nih ${command} Nya 😋`},{quoted: m})
  } catch (e) {
    console.log(e)
    return m.reply(Func.jsonFormat(e))
  }
}
handler.help = handler.command = ['baka','smug','neko_sfw','hentai_gif','spank','blowjob','cumarts','eroyuri','eroneko','erokitsune','feet','femdom','futanari','holo','holoero','keta','pussyart','tits','trap','yuri','anal','neko','bj','gangbang','bdsm','jahy','panties']
handler.tags = ['nsfw']
handler.premium = true
handler.private = true
module.exports = handler