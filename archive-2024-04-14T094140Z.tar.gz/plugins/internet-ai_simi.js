let fetch = require("node-fetch")
let handler = async (m, { conn, text, usedPrefix, command }) => {
if (!text) throw `*• Example:* ${usedPrefix + command} halo`
try {
let gpt = await (await fetch(`https://itzpire.site/ai/simi-chat?text=${text}&lang=id&toxic=false`)).json()
m.replyy(gpt.result)
} catch(e) {
 throw "`Gk Tau :(`"
}
}
handler.help = ["simi"]
handler.tags = ["ai"]
handler.command = ["simi"]
module.exports = handler