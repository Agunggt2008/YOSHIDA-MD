let handler = async (m, { conn, text, usedPrefix, command }) => {
  if (!text) throw `*• Example:* ${usedPrefix + command} halo`
m.react('🌺')
try {
let gpt = await (await fetch(`https://itzpire.site/ai/botika?q=${text}&user=${m.sender}&model=sindy`)).json()
let api = `https://itzpire.site/tools/tts-tiktok?text=${gpt.result}&id=id_001`
await conn.sendFile(m.chat, api, 'sindy.mp3', null, m, true, {
        type: 'audioMessage',
        ptt: true
    })
 } catch(e) {
 throw "`*Gpt Not Responded*`"
}
}
handler.help = ["sindy"]
handler.tags = ["ai"]
handler.command = ["sindy"]

module.exports = handler