let handler = async (m, {
    conn
}) => {
    let lastHuntTime = global.db.data.users[m.sender].lastberburu || 0;
    let cooldown = 24 * 60 * 60 * 1000; // 1 day cooldown

    if (new Date() - lastHuntTime < cooldown) {
        let remainingCooldown = cooldown - (new Date() - lastHuntTime);
        let remainingTime = clockString(remainingCooldown);
        let edtr = `@${m.sender.split`@`[0]}`
        m.reply(`⏳ Mohon tunggu sebentar sebelum dapat berburu lagi.\n\n*Waktu Tersisa:*${remainingTime}`);
        return;
    }

    let habitats = {
        'Hutan 🌿': ['🐃 Banteng', '🐅 Harimau', '🐐 Kambing', '🐒 Monyet', '🐗 Babihutan', '🐖 Babi'],
        'Sabana 🦁': ['🐘 Gajah', '🐐 Kambing', '🐄 Sapi', '🐖 Babi'],
        'Taman Panda 🐼': ['🐼 Panda'],
        'Danau 🐊': ['🐊 Buaya', '🐄 Sapi', '🐖 Babi'],
        'Lembah 🐂': ['🐂 Kerbau', '🐄 Sapi', '🐖 Babi'],
        'Kebun 🐔': ['🐔 Ayam']
    };

    let results = {};
    let pepek = `@${m.sender.split`@`[0]}`
    let kata = `🏞️ *${pepek} Sedang Berburu 🌿*\n\n`
    conn.reply(m.chat, kata, m)

    setTimeout(() => {
        let res = `*🏞️ HASIL BERBURU *${pepek}* 🏞️*\n\n`;
        for (let habitat in habitats) {
            res += `*${habitat}*\n`;
            for (let animal of habitats[habitat]) {
                let count = Math.floor(Math.random() * 100) + 1;
                res += `${animal}: ${count} ekor\n`;
                let animalName = animal.split(' ')[1].toLowerCase();
                if (!results[animalName]) results[animalName] = 0;
                results[animalName] += count;
            }
            res += '\n';
        }
        res += `*${pepek}* 🏕️`;

        let user = global.db.data.users[m.sender];
        for (let animal in results) {
            user[animal] += results[animal];
        }

        conn.reply(m.chat, res, null);
        user.lastberburu = new Date() * 1;
    }, 5000);
}

handler.help = ['berburu']
handler.tags = ['rpg']
handler.command = /^(berburu)$/i
handler.group = true

module.exports = handler

function clockString(ms) {
    let d = isNaN(ms) ? '--' : Math.floor(ms / 86400000)
    let h = isNaN(ms) ? '--' : Math.floor(ms / 3600000) % 24
    let m = isNaN(ms) ? '--' : Math.floor(ms / 60000) % 60
    let s = isNaN(ms) ? '--' : Math.floor(ms / 1000) % 60
    return ['\n' + d, ' *Hari ☀️*\n ', h, ' *Jam 🕐*\n ', m, ' *Menit ⏰*\n ', s, ' *Detik ⏱️* '].map(v => v.toString().padStart(2, 0)).join('')
}