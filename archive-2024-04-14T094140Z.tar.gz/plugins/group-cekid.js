let handler = async (m, {conn, groupMetadata }) => {
conn.reply(m.chat, `${await groupMetadata.id}`, m)
}
handler.help = ['cekid'].map(a => a + ' *get id group*')
handler.tags = ['group']
handler.command = /^(getid|idgc|cekid)$/i
handler.admin = true

module.exports = handler