const {
    translate
} = require('@vitalets/google-translate-api')
const fetch = require('node-fetch')

const defaultLang = 'ja'
const tld = 'cn'
const key = [
    "z-j740K-G86958S",
    "E96-39N92-3021i",
    "p_438_14M3y731P",
    "e1m_5-75427574p",
    "Y11_0_7-1_536-7",
    "X9F694A4Z278J5d",
    "v5y3b-8374f4467",
    "y4A5M8G566846_Y",
    "w3164-16562-7-8",
    "W6901_y9c1w8883",
    "y7c448852-39006",
]

let handler = async (m, {
    args,
    usedPrefix,
    text,
    command
}) => {

    let yh = key
    let apikey = yh[Math.floor(Math.random() * yh.length)]
    let quot = m.quoted ? m.quoted : m;
    let q = text ? text : quot.text;
    if (!text) throw `Masukan text nya!\n\nExample: ${usedPrefix + command} pagi kawan-kawan`

    try {
        let ress = await translate(text, {
            to: defaultLang,
            autoCorrect: true
        }).catch(_ => null)

        let audio = `https://deprecatedapis.tts.quest/v2/voicevox/audio/?text=${encodeURIComponent(ress.text)}&key=${apikey}`
        await conn.sendFile(m.chat, audio, '', '', m, null, {
     ptt: true,
     waveform: [100, 0, 100, 0, 100, 0, 100],
     contextInfo: {
         externalAdReply: { 
    showAdAttribution: true,
    mediaUrl: global.fb,
    mediaType: 2, 
    description: '',
    title: 'V O I C E V O X',
    body: '',
    thumbnail: await (await fetch(`https://telegra.ph/file/47485f5de7cf749b79a80.jpg`)).buffer(),
    sourceUrl: 'https://voicevox.hiroshiba.jp/'
 	  }
     }
    })
    } catch (e) {
        m.reply('Error!')
    }
}

handler.help = ['voicevox']
handler.tags = ['voice']
handler.command = ['voicevox', 'michi']
handler.limit = true
module.exports = handler 