const { lyrics, lyricsv2 } = require('@bochilteam/scraper')

let handler = async (m, { conn, text, usedPrefix, command }) => {
    let teks = text ? text : m.quoted && m.quoted.text ? m.quoted.text : ''
    if (!teks) throw `Use example ${usedPrefix}${command} hallo`
    const result = await lyricsv2(teks).catch(async _ => await lyrics(teks))
    m.replyy(`
Lyrics *${result.title}*
Author ${result.author}


${result.lyrics}


Url ${result.link}
`.trim())
}

handler.help = ['lirik2'].map(v => v + ' <Judul>')
handler.tags = ['internet']
handler.command = /^(lirik2|lyrics2|lyric2)$/i

module.exports = handler