
const axios = require('axios');

let handler = async (m, { conn, text }) => {
 conn.akira = conn.akira ? conn.akira : {};

 if (!text) throw `*• Example:* .yoshida *[on/off]*`;

 if (text == "on") {
 conn.akira[m.sender] = {
 pesan: []
 }
 m.reply("✓ Berhasil membuat sesi chat")
 } else if (text == "off") {
 delete conn.akira[m.sender]
 m.reply("✓ Berhasil menghapus sesi chat")
 }
}

handler.before = async (m, { conn }) => {
conn.akira = conn.akira ? conn.akira : {};
 if (m.isBaileys && m.fromMe) return;
 if (!m.text) return
 if (!conn.akira[m.sender]) return;

 if (
 m.text.startsWith(".") ||
 m.text.startsWith("#") ||
 m.text.startsWith("!") ||
 m.text.startsWith("/") ||
 m.text.startsWith("\\/")
 ) return

 if (conn.akira[m.sender] && m.text) {
 let name = conn.getName(m.sender)
 let tag = `@${m.sender.split("@")[0]}`
 await conn.sendMessage(m.chat, { react: { text: `💬`, key: m.key }});
 const messages = [
 ...conn.akira[m.sender].pesan,
 { role: "system", content: `Kamu bernama yoshida berumur 20 kamu adalah asistennya yang dapat menjawab segala pertanyaan dan kamu diciptakan oleh seorang developer bernama Adi Selebew, gunakan bahasa gaul lu gw saat menjawab, gunakan emoji pada saat ingin menjawab pertanyaan, kamu memiliki sifat cuek namun feminin seperti seorang wanita, kamu memiliki pacar bernama Adi Selebew tercinta, jika ada pertanyaan berkait tentang agama kamu jawab penolakan, sapa nama lawan bicara mu ${tag}"` },
 { role: "user", content: m.text }
 ];
 try {
 const response = await axios.post("https://deepenglish.com/wp-json/ai-chatbot/v1/chat", {
 messages
 });

 const responseData = response.data;
 const hasil = responseData;
 await conn.sendMessage(m.chat, { react: { text: `✨`, key: m.key }});
 m.replyy(hasil.answer)
 conn.akira[m.sender].pesan = messages
 } catch (error) {
 console.error("Error fetching data:", error);
 throw error;
 }
 }
}

handler.command = ['yoshida'];
handler.tags = ["ai"]
handler.help = ['yoshida'].map(a => a + " *on/off*");

module.exports = handler