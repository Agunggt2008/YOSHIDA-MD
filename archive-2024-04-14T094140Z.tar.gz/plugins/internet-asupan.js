let handler = async(m, { conn }) => {
  const asupan = [
    `https://api.botcahx.eu.org/api/asupan/rikagusriani?apikey=${global.btc}`,
    `https://api.botcahx.eu.org/api/asupan/santuy?apikey=${global.btc}`,
    `https://api.botcahx.eu.org/api/asupan/ukhty?apikey=${global.btc}`,
    `https://api.botcahx.eu.org/api/asupan/bocil?apikey=${global.btc}`,
    `https://api.botcahx.eu.org/api/asupan/gheayubi?apikey=${global.btc}`,
    `https://api.botcahx.eu.org/api/asupan/natajadeh?apikey=${global.btc}`,
    `https://api.botcahx.eu.org/api/asupan/euni?apikey=${global.btc}`,
    `https://api.botcahx.eu.org/api/asupan/douyin?apikey=${global.btc}`,
    `https://api.botcahx.eu.org/api/api/asupan/cecan?apikey=${global.btc}`,
    `https://api.botcahx.eu.org/api/api/asupan/hijaber?apikey=${global.btc}`,
    `https://api.botcahx.eu.org/api/api/asupan/asupan?apikey=${global.btc}`,
    `https://api.botcahx.eu.org/api/api/asupan/anony?apikey=${global.btc}`   
  ]
  try {
    const url = pickRandom(asupan);
    await conn.sendFile(m.chat, url, null, '', m);
  } catch (e) {
    console.log(e);
    m.reply('Maaf, video asupan tidak ditemukan');
  }
}

handler.help = ['asupan']
handler.tags = ['internet']
handler.command = /^asupan$/i
handler.owner = false
handler.premium = true
handler.group = false
handler.private = false

function pickRandom(list) {
  return list[Math.floor(list.length * Math.random())]
}

module.exports = handler