const loli = require("@Im-Dims/scraper")
const axios = require("axios")

let handler = async (m, {conn, args, usedPrefix, text, command }) => {
if (!args[0]) return m.reply(Func.example(usedPrefix, command, 'https://vt.tiktok.com/ZSF65MpbQ/'))
m.react('🕛')

try {
let anu = await tt(args[0])
let iya = anu.data

if (iya?.images?.length) {
hh = iya.images
let c = 0, d = hh.length

for (let wow of hh) {
if (c == 0) await conn.sendFile(m.chat, wow, '', `Mengirim 1 dari ${hh.length} slide gambar.`, m)
else await conn.sendFile(m.chat, wow, '', null, m)
c += 1
await Func.delay(2000)
}

} else {
let tete = await loli.tiktok.download(args[0])

conn.sendFile(m.chat, tete.video[0].url, '', tete.description, m)
await conn.sendMessage(m.chat, {
    audio: {
    url: `${tete.video[0].url}`
    },
    mimetype: 'audio/mp4', 
    fileName: `${tete.description}.mp3`
    },{ quoted: m})}
} catch (e) {
m.reply(Func.jsonFormat(e))
}
}
handler.help = ['tiktok']
handler.tags = ['downloader']
handler.command = /^(tiktok|tt|ttdl|tiktoknowm)$/i
handler.limit = 2

module.exports = handler

async function tt(url) {
  let response = await axios.post("https://www.tikwm.com/api", {}, {
    params: {
      url: url,
      count: 12,
      cursor: 0,
      web: 1,
      hd: 1
    }
  });
  return response.data;
}