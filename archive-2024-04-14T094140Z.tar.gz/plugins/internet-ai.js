let Baileys = require("@whiskeysockets/baileys")
let handler = async (m, {
    usedPrefix,
    command,
    text
}) => {
    if (!text) return m.reply(Func.example(usedPrefix, command, 'input teks!'))
     m.react('💬')
    try {
        if (command == 'openai') {
            let json = await Func.fetchJson(API('alya', '/api/openai', { prompt: text }, 'apikey'))
            if (!json.status) return m.reply(Func.jsonFormat(json))
const msg = Baileys.generateWAMessageFromContent(
			m.chat,
			{
				interactiveMessage: {
					body: {
						text: json.data.content
					},
					footer: {
						text: '_©2024 Powered By Openai_'
					},
					header: {
						title: '',
						hasMediaAttachment: false,
						// ...image.message,
					},
					nativeFlowMessage: {
						buttons: [ { text: "Anjayy"} ]
					}
				}, 
			},
			{
				quoted: m
			}
		);
  await conn.relayMessage(m.chat, msg.message, m)

        } else if (command == 'ai-img') {
            let json = await Func.fetchJson(API('alya', '/api/ai-img', { prompt: text }, 'apikey'))
            if (!json.status) return m.reply(Func.jsonFormat(json))
            conn.sendFile(m.chat, json.data[0].url, 'ai-img.jpg', 'Result...', m)
        }
    } catch (e) {
        console.log(e)
        return m.reply(status.error)
    }
}
handler.help = handler.command = ['openai', 'ai-img']
handler.tags = ['ai']
handler.limit = 1
module.exports = handler