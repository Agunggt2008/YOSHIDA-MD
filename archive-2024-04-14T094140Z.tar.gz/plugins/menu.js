let levelling = require('../lib/levelling')
let fs = require('fs')
let path = require('path')
let moment = require('moment-timezone')
let os = require('os')
const { generateForwardMessageContent, proto } = require('@whiskeysockets/baileys').default 
const defaultMenu = {
before: `Hai *%pushname* 👋🏻

┌═ᙍ ɪɴꜰᴏ ᙊ
│⁠ *Total user:* %totalreg
│⁠ *Uptime:* %uptime
│ *Library:* Baileys
└══╼ᙍᙊ ‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎
%readmore`.trimStart(),
header:`╭╼❲ %category ❳`,
body: `│⌬ %cmd %isPremium %islimit`,
footer: `╰▱╼❲ _©2024_ ❳\n`,
after: wm,
}

let handler = async (m, { 
  conn, 
  usedPrefix: _p, 
  args, 
  command, 
  setting
}) => {
  let tags
  let teks = `${args[0]}`.toLowerCase()
  let arrayMenu = [ 'islami', 'quotes', 'ai', 'anonymous', 'database', 'downloader', 'effect', 'fun', 'game', 'genshin', 'group', 'info', 'internet', 'maker', 'nsfw', 'owner', 'primbon', 'rpg', 'sticker', 'tools', 'xp', 'voice']
  if (!arrayMenu.includes(teks)) teks = '404'
 if (teks == 'ai') tags = {
    ai: '👒 AI'
  }
    if (teks == 'anonymous') tags = {
    anonymous: '👾 ANONYMOUS'
  }
  if (teks == 'database') tags = {
    database: '🗂️ DATABASE'
  }
  if (teks == 'downloader') tags = {
    downloader: '📥 DOWNLOADER'
  }
  if (teks == 'effect') tags = {
    effect: '🪄 EFFECT'
  }
  if (teks == 'fun') tags = {
    fun: '🎯 FUN'
  }
  if (teks == 'game') tags = {
    game: '🎮 GAME'
  }
    if (teks == 'genshin') tags = {
    genshin: '🎋 GENSHIN'
  }
  if (teks == 'group') tags = {
    group: '👥 GROUP'
  }
  if (teks == 'info') tags = {
    info: '💡INFO'
  }
  if (teks == 'internet') tags = {
    internet: '📡 INTERNET'
  }
   if (teks == 'islami') tags = {
    islami: '🕌 ISLAMI'
  }
  if (teks == 'nsfw') tags = {
    nsfw: '🔥 NSFW'
  }
  if (teks == 'maker') tags = {
    maker: '🔮 MAKER'
  }
  if (teks == 'owner') tags = {
    owner: '👑 OWNER'
  }
  if (teks == 'primbon') tags = {
    primbon: '⚗️ PRIMBON'
  }
  if (teks == 'quotes') tags = {
    quotes: '📝 QUOTES'
  }
    if (teks == 'rpg') tags = {
    rpg: '🕹️ ROLEPLAY GAME'
  }
  if (teks == 'sticker') tags = {
    sticker: '🏷️ STICKER'
  }
  if (teks == 'tools') tags = {
    tools: '🛠️ TOOLS'
  }
  if (teks == 'xp') tags = {
    xp: '📢 USER INFO'
  }
  if (teks == 'voice') tags = {
    voice: '🎤 VOICE'
  }
  try {
    let package = JSON.parse(await fs.promises.readFile(path.join(__dirname, '../package.json')).catch(_ => '{}'))
    let { exp, limit, level, role, registered } = global.db.data.users[m.sender]
    let premium = global.db.data.users[m.sender].premiumTime
    let prems = `${premium > 0 ? "Premium 👑": "Free"}`
    let { min, xp, max } = levelling.xpRange(level, global.multiplier)
    let me = conn.getName(conn.user.jid)
    let sender = m.key.fromMe ? (conn.user.id.split(':')[0]+'@s.whatsapp.net' || conn.user.id) : (m.key.participant || m.key.remoteJid)
    let tag = `@${m.sender.split("@")[0]}`
    let pushname = m.pushName
    let name = registered ? global.db.data.users[m.sender].name : conn.getName(m.sender)
    let d = new Date(new Date + 3600000)
    let locale = 'id'
    let sound = fs.readFileSync('./media/menu.mp3')
    let platform = os.platform()
    let mode = global.opts["self"] ? "Private" : "Publik"
     
    // d.getTimeZoneOffset()
    // Offset -420 is 18.00
    // Offset    0 is  0.00
    // Offset  420 is  7.00
    let wib = moment.tz('Asia/Jakarta').format('HH:mm:ss')
    let bottime = `𝗧 𝗜 𝗠 𝗘 : ${wib}`
    let weton = ['Pahing', 'Pon', 'Wage', 'Kliwon', 'Legi'][Math.floor(d / 84600000) % 5]
    let week = d.toLocaleDateString(locale, { weekday: 'long' })
    let date = d.toLocaleDateString(locale, {
      day: 'numeric',
      month: 'long',
      year: 'numeric'
    })
    let tanggalislam = Intl.DateTimeFormat(locale + '-TN-u-ca-islamic', {
      day: 'numeric',
      month: 'long',
      year: 'numeric'
    }).format(d)
    let time = d.toLocaleTimeString(locale, {
      hour: 'numeric',
      minute: 'numeric',
      second: 'numeric'
    })
    let _uptime = process.uptime() * 1000
    let _muptime
    if (process.send) {
      process.send('uptime')
      _muptime = await new Promise(resolve => {
        process.once('message', resolve)
        setTimeout(resolve, 1000)
      }) * 1000
    }
    let muptime = clockString(_muptime)
    let uptime = clockString(_uptime)
    let totalreg = Object.keys(global.db.data.users).length
    let rtotalreg = Object.values(global.db.data.users).filter(user => user.registered == true).length
    let help = Object.values(global.plugins).filter(plugin => !plugin.disabled).map(plugin => {
      return {
        help: Array.isArray(plugin.help) ? plugin.help : [plugin.help],
        tags: Array.isArray(plugin.tags) ? plugin.tags : [plugin.tags],
        prefix: 'customPrefix' in plugin,
        limit: plugin.limit,
        premium: plugin.premium,
        enabled: !plugin.disabled,
      }
    })
if (teks == '404') {
m.react('✨')
let capt = `Haiii @${m.sender.replace(/@.+/g, '')}! 👋🏻\n`
let cap = `
I am an automatic system (WhatsApp Bot)

⛨〡 *Library* : _@baileys_
⛨〡 *Creator* : +62 882-0078-55266
⛨〡 *Powered By* : _NodeJs_

╭─➤ *FEATURE LIST*
│${_p + command} Ai
│${_p + command} Anonymous
│${_p + command} Database
│${_p + command} Downloader
│${_p + command} Effect
│${_p + command} Fun
│${_p + command} Game
│${_p + command} Group
│${_p + command} Genshin
│${_p + command} Info
│${_p + command} Islami
│${_p + command} Internet
│${_p + command} Maker
│${_p + command} Owner
│${_p + command} Primbon
│${_p + command} Quotes
│${_p + command} Rpg
│${_p + command} Sticker
│${_p + command} Tools
│${_p + command} Xp
│${_p + command} Voice
╰─╯

To See All Features Type : *\`.allmenu\`*`
return conn.reply(m.chat, capt + readMore + Func.Styles(cap), m)
    }
    let groups = {}
    for (let tag in tags) {
      groups[tag] = []
      for (let plugin of help)
        if (plugin.tags && plugin.tags.includes(tag))
          if (plugin.help) groups[tag].push(plugin)
      // for (let tag of plugin.tags)
      //   if (!(tag in tags)) tags[tag] = tag
    }
    conn.menu = conn.menu ? conn.menu : {}
    let before = conn.menu.before || defaultMenu.before
    let header = conn.menu.header || defaultMenu.header
    let body = conn.menu.body || defaultMenu.body
    let footer = conn.menu.footer || defaultMenu.footer
    let after = conn.menu.after || (conn.user.jid == global.conn.user.jid ? '' : `Dipersembahkan oleh https://wa.me/${global.conn.user.jid.split`@`[0]}`) + defaultMenu.after
    let _text = [
      before,
      ...Object.keys(tags).map(tag => {
        return header.replace(/%category/g, tags[tag]) + '\n' + [
          ...help.filter(menu => menu.tags && menu.tags.includes(tag) && menu.help).map(menu => {
            return menu.help.map(help => {
              return body.replace(/%cmd/g, menu.prefix ? help : '%p' + help)
                .replace(/%islimit/g, menu.limit ? 'Ⓛ︎' : '')
                .replace(/%isPremium/g, menu.premium ? '🅟' : '')
                .trim()
            }).join('\n')
          }),
          footer
        ].join('\n')
      }),
      after
    ].join('\n')
    text = typeof conn.menu == 'string' ? conn.menu : typeof conn.menu == 'object' ? _text : ''
    let replace = {
      '%': '%', mode, platform, wib, more, after, menuju1, menuju2, prems, pushname, tag, p: _p, uptime, muptime, me: conn.user.name, npmname: package.name, npmdesc: package.description, version: package.version, exp: exp - min, maxexp: xp, totalexp: exp, xp4levelup: max - exp <= 0 ? `Siap untuk *${_p}levelup*` : `${max - exp} XP lagi untuk levelup`, github: package.homepage ? package.homepage.url || package.homepage : '[unknown github url]', level, limit, name, weton, week, date, tanggalislam, time, totalreg, rtotalreg, role, readmore: readMore
    }
    text = text.replace(new RegExp(`%(${Object.keys(replace).sort((a, b) => b.length - a.length).join`|`})`, 'g'), (_, name) => '' + replace[name])
    conn.sendMessage(m.chat,{text: Func.Styles(text.trim()), contextInfo: {
    mentionedJid: [],
    groupMentions: [],
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
      newsletterJid: '120363187172910457@newsletter',
      newsletterName: '⎙ YOSHIDA-TECH',
      serverMessageId: -1
    },
    businessMessageForwardInfo: { businessOwnerJid: `6282375933838@s.whatsapp.net` },
    forwardingScore: 256,
    externalAdReply: {
      title: date,
      body: bottime,
      thumbnailUrl: Randompoto(),
      sourceUrl: saluran,
      mediaType: 1,
      renderLargerThumbnail: true
    }
  }
},{quoted: m})  
} catch (e) {
    conn.reply(m.chat, 'Maaf menu sedang error..❗', m)
    throw e
  }
}
handler.help = ['menu']
handler.command = /^(menu|help)$/i
handler.exp = 3
module.exports = handler

function pickRandom(list) {
  return list[Math.floor(Math.random() * list.length)]
}
const more = String.fromCharCode(8206)
const readMore = more.repeat(4001)

// Memilih Secara Acak satu Mimetype
function Rpepek() {
const pepek = [
"application/pdf",
"application/msword",
"application/vnd.ms-excel",
"application/vnd.ms-powerpoint",
"application/x-rar-compressed",
"application/vnd.openxmlformats-officedocument.presentationml.      presentation",
"application/vnd.openxmlformats-officedocument.spreadsheetml.      sheet",
"application/vnd.openxmlformats-officedocument.wordprocessingml.   document"
];
const randomIndex = Math.floor(Math.random() * pepek.length);
return pepek[randomIndex];
}
function Randompoto() {
const poto = [
"https://telegra.ph/file/762086a42b15ac753de0c.jpg",
"https://telegra.ph/file/54fa71526c3118a8dc960.jpg",
"https://telegra.ph/file/4bdd0c2970d0e74f423b2.jpg",
"https://telegra.ph/file/8c87424ec56a046299b5a.jpg",
"https://telegra.ph/file/f696f95c842c008cb90b0.jpg",
"https://telegra.ph/file/4081be70f8a287c0c111d.jpg",
"https://telegra.ph/file/cb1af4fb4825e62f05288.jpg",
"https://telegra.ph/file/683ae007eb245913abec6.jpg",
"https://telegra.ph/file/208aba5fa13b87b7f6de5.jpg",
"https://telegra.ph/file/43cd874e7054df88c6047.jpg",
"https://telegra.ph/file/630097396fb0486fe1a9a.jpg",
"https://telegra.ph/file/33ebf79b861e49779200a.jpg",
"https://telegra.ph/file/d183fe5e18a4d91a4cc44.jpg",
"https://telegra.ph/file/f8353af93c8f7f8f6d52a.jpg",
"https://telegra.ph/file/af60c65f7fe7cd672dfca.jpg",
"https://telegra.ph/file/77cc242726cb4d9a93352.jpg",
"https://telegra.ph/file/1cfaef59e4f8d28e24b97.png"
];
const randomIndex = Math.floor(Math.random() * poto.length);
return poto[randomIndex];
}
//Hitung Mundur 
       const HBD = new Date('December 09, 2024 06:00:00').getTime();
        const sekarang = new Date().getTime();
        const Selisih = HBD - sekarang;
        const jhari = Math.floor(Selisih / (1000 * 60 * 60 * 24));
        const menuju = `${jhari} hari`
        
        const puasa = new Date('Maret 10, 2024 06:00:00').getTime();
        const sekarang1 = new Date().getTime();
        const Selisih1 = puasa - sekarang;
        const jhari1 = Math.floor(Selisih1 / (1000 * 60 * 60 * 24));
        const menuju1 = `${jhari1} hari`
        
        const TahunBaru = new Date('Januari 01, 2025 00:01:00').getTime();
        const sekarang2 = new Date().getTime();
        const Selisih2 = TahunBaru - sekarang;
        const jhari2 = Math.floor(Selisih2 / (1000 * 60 * 60 * 24));
        const menuju2 = `${jhari2} hari`


function clockString(ms) {
  let h = isNaN(ms) ? '--' : Math.floor(ms / 3600000)
  let m = isNaN(ms) ? '--' : Math.floor(ms / 60000) % 60
  let s = isNaN(ms) ? '--' : Math.floor(ms / 1000) % 60
  return [h, m, s].map(v => v.toString().padStart(2, 0)).join(':')
}

function emot() {
const time = moment.tz('Asia/Jakarta').format('HH')
let res = "💤"
if (time >= 4) {
res = "🍟"
}
if (time >= 10) {
res = "👋"
}
if (time >= 16) {
res = "🍭"
}
if (time >= 18) {
res = "🚬"
}
if (time >= 19) {
res = "☕"
}
return res
}
function ucapan() {
  const time = moment.tz('Asia/Jakarta').format('HH')
  res = 'Selamat Begadang 😴'
  if (time >= 5) {
    res = 'Selamat Pagi'
  }
  if (time > 10) {
    res = 'Selamat Siang'
  }
  if (time >= 15) {
    res = 'Selamat Sore'
  }
  if (time >= 18) {
    res = 'Selamat Malam'
  }
  return res
}
function Pagi() {
    let waktunya = moment.tz("Asia/Jakarta").format("HH");
    return waktunya >= 24 ? "Selamat Begadang 🗿 " :
        waktunya >= 18 ? "Selamat malam 🌙 " :
        waktunya >= 15 ? "Selamat sore 🌇 " :
        waktunya > 10 ? "Selamat siang ☀️ " :
        waktunya >= 4 ? "Selamat pagi 🌄 " :
        "Selamat Pagi 🗿 ";
}
function Sapa() {
    let Apa = pickRandom(["Apa kabar ", "Halo ", "Hai "])
    return Apa
}
function wayah() {
const time = moment.tz('Asia/Jakarta').format('HH')
let res = "Jangan Lupa Istirahat 😴"
if (time >= 5) {
res = "Selamat Pagi 🌄"
}
if (time >= 10) {
res = "Selamat Siang ☀️"
}
if (time >= 16) {
res = "Selamat Sore 🌇"
}
if (time >= 18) {
res = "Selamat Petang 🌆"
}
if (time >= 19) {
res = "Selamat Malam 🌙"
}
return res
}
function timeimg() {
const time = moment.tz('Asia/Jakarta').format('HH')
let imgloc = "https://telegra.ph/file/abdc8001f71207443525e.jpg"
if (time >= 0) {
imgloc = "https://telegra.ph/file/abdc8001f71207443525e.jpg"
}
if (time >= 4) {
imgloc = "https://telegra.ph/file/ed20b6cc11b879d8a1815.jpg"
}
if (time >= 6) {
imgloc = "https://telegra.ph/file/ed20b6cc11b879d8a1815.jpg"
}
if (time >= 10) {
imgloc = "https://telegra.ph/file/ab70477ab30762545e51b.jpg"
}
if (time >= 16) {
imgloc = "https://telegra.ph/file/958081826bc8287082485.jpg"
}
if (time >= 18) {
imgloc = "https://telegra.ph/file/958081826bc8287082485.jpg"
}
if (time >= 20) {
imgloc = "https://telegra.ph/file/abdc8001f71207443525e.jpg"
}
return imgloc
}