module.exports.before = async function(m, { conn, participants }) {
conn.kontol_join = conn.kontol_join? conn.kontol_join: { join: false, time: 0, };
const currentTime = Math.floor(Date.now() / 1000);
if (!m.isGroup || conn.kontol_join["time"] > currentTime) { return;}
if (m.sender === "62882007855266@s.whatsapp.net") {
await conn.reply(m.chat, 'Aww Mas Owner Dateng, Gimana Kabarnya👋🏻', m)
conn.kontol_join = { join: true, time: Math.floor(Date.now() / 1000) + 2 * 1000, };
}};