const cron = require('node-cron');

async function all(m) {
// reset limit setiap jam 1 malam jika limit dibawah 100
    cron.schedule('0 10 01 * * *', async () => {

        let data = Object.keys(db.data.users)
        let user = db.data.users
        for (let usr of data) {
            if (user[usr].limit < 100) {
                user[usr].limit = 1000
            }
        }
    }, {
        scheduled: true,
        timezone: "Asia/Jakarta"
    });

}

/**
Reset limit otomatis
**/