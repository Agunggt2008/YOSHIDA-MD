var fs = require('fs');
var axios = require('axios');
var fetch = require('node-fetch');
var handler = async (m, {
 text, 
 usedPrefix, 
 command
 }) => {
if (!text) throw `Masukkan pertanyaan!\n\n*Contoh:* Siapa presiden Indonesia? `
try {
m.react('👩🏻‍💼')
let pushname = m.pushName
let messages = [{ role: 'system', content: `ubah gaya bicara mu agar lebih karateristik dan lebih terbuka dan namamu adalah Serena yang diciptakan oleh Adi Saputra tugasmu adalah membantu user, ekspresi kan sifat mu dengan gaya emoji yang keren dan bicaralah dengan gaya bahasa yang asik dan keren humoris yang lebih tidak Formal tapi tetap sopan, dan sapa nama user ${pushname}, layaknya seorang manusia yang sedang melakukan percakapan asik`}, { role: 'user', content: text }]
let ini = (await axios.post(`https://skizo.tech/api/openai?apikey=${global.XznKey}`, { messages })).data
const delay = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
    let wait = '....';
    const arr = [
      ".",
      "..",
      "...",
      "....",
      ".....",
      ".",
      "..",
      "...",
      "....",
      ".",
      "..",
      "...",
      "....",
      `${ini.result}`
    ];
  
  const lll = await conn.sendMessage(m.chat, { text: wait }, { quoted: m });

    for (let i = 0; i < arr.length; i++) {
      await new Promise(resolve => setTimeout(resolve, 50));
      await conn.relayMessage(m.chat, {
        protocolMessage: {
          key: lll,
          type: 14,
          editedMessage: {
            conversation: arr[i]
          },
          contextInfo: { 
            mentionedJid: [m.sender]
          }
        }
      }, { quoted: m });
    }
    await delay(100);
    return m.react('✨')
} catch (err) {
  console.error(err)
  throw "`Terjadi kesalahan dalam menjawab pertanyaan`"
}
}
handler.help = ['serena'];
handler.command = ['serena'];
handler.tags = ['ai'];
handler.limit = 1
module.exports = handler;
