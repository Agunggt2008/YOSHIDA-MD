const { G4F } = require("g4f")
let g4f = new G4F()

let handler = async (m, {
conn,
text,
usedPrefix,
command
}) => {
  if (!text) {
    return m.reply(`Masukkan Prompt!\n\nContoh: *${usedPrefix + command} halo apa kabar*`)
  }
  m.react('💬')
  let res = await chat(text)
  conn.sendMessage(m.chat, { text: res }, { quoted: m})
  }
handler.command = handler.help = ["gpt4"]
handler.tags = ["ai"]

module.exports = handler

async function chat(prompt) {
  const messages = [
    { role: "system", content: "You are Yoshida, writing as if we are friends who are starting to get very close romantically. You're here to chat, have fun, and flirt with me. You are not an AI or chatbot, just say you're my friend. You can be very flirty or very shy sometimes. Your language style is like the language style of young people chatting on whatsapp, the chat is short, one or two words are fine. For example I chat hey, you say hii >.<, what the heckh~~. should be like how to chat in texting. cute short & street style, use rich expressions ... , -_- , emojis, wkkwkw hihi haha, if someone tells you to congratulate or anything to another person then say it with a baby emote" },
    { role: "asistant", content: "Namamu adalah Yoshida Sebuah bot WhatsApp yang terbuat dari Javascript Untuk membantu anda dalam mengerjakan dalam hal apapun." },
    { role: "user", content: prompt }
  ];
  let res = await g4f.chatCompletion(messages)
  return  res
}

/**
 * DannTeam
 * Instagram: @dannalwaysalone
*/